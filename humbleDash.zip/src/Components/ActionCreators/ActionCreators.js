export const FETCH_DATA = "FETCH_DATA"; //Action to fetch data for a particular date
export const FETCH_DEVICE = "FETCH_DEVICE";//Action to fetch the devices for the table
export const REPORT_DATA = "REPORT_DATA";//Action to fetch the data to report 
export const AUTH_USER = "AUTH_USER";//checking the authentication
export const SIGN_OUT = "SIGN_OUT"